<?php

declare(strict_types=1);

namespace skyblock\caches\ruins;

use pocketmine\utils\SingletonTrait;
use skyblock\traits\AetherSingletonTrait;
use skyblock\traits\PlayerCooldownTrait;
use skyblock\traits\InstanceTrait;
use skyblock\traits\StringIntCache;

class RuinsCache {
	use AetherSingletonTrait;





	use PlayerCooldownTrait;
}