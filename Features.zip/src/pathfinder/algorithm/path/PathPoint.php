<?php

declare(strict_types=1);

namespace pathfinder\algorithm\path;

use pocketmine\math\Vector3;

class PathPoint extends Vector3 {
}