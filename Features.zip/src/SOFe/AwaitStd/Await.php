<?php

namespace SOFe\AwaitStd;

use SOFe\AwaitGenerator\Await as Shaded;

class_alias(Shaded::class, __NAMESPACE__ . "\\Await");
